const OPENAI_API_KEY = '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'; // Use env variable in production

export const getAISummary = async (noteContent) => {
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${OPENAI_API_KEY }`,
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content:
              'You are a helpful assistant. Summarize the following note in 2-3 bullet points.',
          },
          {
            role: 'user',
            content: noteContent,
          },
        ],
        max_tokens: 150,
      }),
    });

    const data = await response.json();
    // Log full response for debugging
    if (!response.ok) {
      console.log('OpenAI API error:', data);
      return data.error?.message || 'Unable to generate summary. Please try again.';
    }
    if (data.choices && Array.isArray(data.choices) && data.choices.length > 0 && data.choices[0].message && data.choices[0].message.content) {
      return data.choices[0].message.content;
    } else {
      console.log('Unexpected OpenAI response:', data);
      return 'Unable to generate summary. Please try again.';
    }
  } catch (error) {
    console.log('AI Error:', error);
    return 'Unable to generate summary. Please try again.';
  }
};