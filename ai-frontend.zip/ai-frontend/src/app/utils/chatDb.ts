import SQLite, { SQLiteDatabase } from "react-native-sqlite-storage";

export type ChatMessage = { role: "user" | "assistant"; content: string };

let dbInstance: SQLiteDatabase | null = null;
let promiseEnabled = false;

async function getDb(): Promise<SQLiteDatabase> {
  if (!dbInstance) {
    // Enable promise mode lazily — must happen before the first openDatabase call
    if (!promiseEnabled) {
      SQLite.enablePromise(true);
      promiseEnabled = true;
    }
    dbInstance = await SQLite.openDatabase({ name: "chat.db", location: "default" });
  }
  return dbInstance;
}

export async function initDb(): Promise<void> {
  const db = await getDb();
  await db.executeSql(`
    CREATE TABLE IF NOT EXISTS messages (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      role       TEXT    NOT NULL,
      content    TEXT    NOT NULL,
      created_at INTEGER NOT NULL
    )
  `);
}

export async function saveMessage(
  role: "user" | "assistant",
  content: string
): Promise<void> {
  const db = await getDb();
  await db.executeSql(
    "INSERT INTO messages (role, content, created_at) VALUES (?, ?, ?)",
    [role, content, Date.now()]
  );
}

export async function loadMessages(): Promise<ChatMessage[]> {
  const db = await getDb();
  const [results] = await db.executeSql(
    "SELECT role, content FROM messages ORDER BY created_at ASC"
  );
  const rows: ChatMessage[] = [];
  for (let i = 0; i < results.rows.length; i++) {
    rows.push(results.rows.item(i) as ChatMessage);
  }
  return rows;
}

export async function clearMessages(): Promise<void> {
  const db = await getDb();
  await db.executeSql("DELETE FROM messages");
}
