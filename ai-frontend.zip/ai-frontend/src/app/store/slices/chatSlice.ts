import { createSlice, PayloadAction } from "@reduxjs/toolkit";

type Message = { role: "user" | "assistant"; content: string };

interface ChatState {
  messages: Message[];
  streaming: boolean;
}

const initialState: ChatState = {
  messages: [],
  streaming: false,
};

const chatSlice = createSlice({
  name: "chat",
  initialState,
  reducers: {
    loadMessages: (state, action: PayloadAction<Message[]>) => {
      state.messages = action.payload;
    },
    addMessage: (state, action: PayloadAction<Message>) => {
      state.messages.push(action.payload);
    },
    updateLastMessage: (state, action: PayloadAction<string>) => {
      const lastIndex = state.messages.length - 1;
      state.messages[lastIndex].content += action.payload;
    },
    setStreaming: (state, action: PayloadAction<boolean>) => {
      state.streaming = action.payload;
    },
    clearMessages: (state) => {
      state.messages = [];
    },
  },
});

export const { loadMessages, addMessage, updateLastMessage, setStreaming, clearMessages } =
  chatSlice.actions;
export default chatSlice.reducer;