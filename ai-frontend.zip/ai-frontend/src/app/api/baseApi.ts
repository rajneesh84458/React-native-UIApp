import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

const BASE_URL = __DEV__
  ? "http://10.0.2.2:5000"   // Android emulator → host machine
  : "http://localhost:5000";  // iOS simulator or production

export const baseApi = createApi({
  reducerPath: "api",
  baseQuery: fetchBaseQuery({
    baseUrl: BASE_URL,
    prepareHeaders: (headers, { getState }) => {
      const token = (getState() as any).auth.accessToken;
      if (token) {
        headers.set("Authorization", `Bearer ${token}`);
      }
      return headers;
    },
  }),
  endpoints: () => ({}),
});