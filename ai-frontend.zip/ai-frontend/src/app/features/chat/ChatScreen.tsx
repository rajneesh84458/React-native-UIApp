import React, { useState, useRef, useEffect } from "react";
import {
  View,
  TextInput,
  ScrollView,
  Text,
  TouchableOpacity,
  StyleSheet,
  Animated,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { addMessage, updateLastMessage, setStreaming, loadMessages } from "../../store/slices/chatSlice";
import { createStream, BASE_URL } from "../../utils/eventSource";
import { initDb, saveMessage, loadMessages as loadFromDb } from "../../utils/chatDb";

// ── Typing dots ──────────────────────────────────────────────────────────────
function TypingDots() {
  const dot0 = useRef(new Animated.Value(0)).current;
  const dot1 = useRef(new Animated.Value(0)).current;
  const dot2 = useRef(new Animated.Value(0)).current;
  const dots = [dot0, dot1, dot2];

  useEffect(() => {
    const animations = dots.map((dot, i) =>
      Animated.loop(
        Animated.sequence([
          Animated.delay(i * 150),
          Animated.timing(dot, { toValue: -6, duration: 300, useNativeDriver: true }),
          Animated.timing(dot, { toValue: 0,  duration: 300, useNativeDriver: true }),
          Animated.delay((2 - i) * 150),
        ])
      )
    );
    animations.forEach((a) => a.start());
    return () => animations.forEach((a) => a.stop());
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dot0, dot1, dot2]);

  return (
    <View style={styles.dotsRow}>
      {dots.map((dot, i) => (
        <Animated.View
          key={i}
          style={[styles.dot, { transform: [{ translateY: dot }] }]}
        />
      ))}
    </View>
  );
}

// ── Main screen ──────────────────────────────────────────────────────────────
export default function ChatScreen() {
  const [input, setInput] = useState("");
  const dispatch = useDispatch();
  const { messages, streaming } = useSelector((state: any) => state.chat);
  const token = useSelector((state: any) => state.auth.accessToken);
  const scrollRef = useRef<ScrollView>(null);
  const streamRef = useRef<{ close: () => void } | null>(null);
  const assistantBufferRef = useRef("");

  // Init DB and restore history on mount
  useEffect(() => {
    (async () => {
      await initDb();
      const saved = await loadFromDb();
      if (saved.length > 0) dispatch(loadMessages(saved));
    })();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Auto-scroll whenever messages change
  useEffect(() => {
    scrollRef.current?.scrollToEnd({ animated: true });
  }, [messages]);

  const stopGenerating = () => {
    streamRef.current?.close();
    streamRef.current = null;
    if (assistantBufferRef.current.trim()) {
      saveMessage("assistant", assistantBufferRef.current);
      assistantBufferRef.current = "";
    }
    dispatch(setStreaming(false));
  };

  const sendMessage = () => {
    if (!input.trim() || streaming) return;

    const text = input.trim();
    dispatch(addMessage({ role: "user", content: text }));
    dispatch(addMessage({ role: "assistant", content: "" }));
    dispatch(setStreaming(true));
    setInput("");
    saveMessage("user", text);
    assistantBufferRef.current = "";

    streamRef.current = createStream(
      `${BASE_URL}/ai/stream`,
      token,
      { message: text },
      (chunk) => {
        assistantBufferRef.current += chunk;
        dispatch(updateLastMessage(chunk));
      },
      (errMsg) => {
        console.log("[CHAT] Stream error:", errMsg);
        if (assistantBufferRef.current.trim()) {
          saveMessage("assistant", assistantBufferRef.current);
          assistantBufferRef.current = "";
        }
        streamRef.current = null;
        dispatch(setStreaming(false));
      },
      () => {
        if (assistantBufferRef.current.trim()) {
          saveMessage("assistant", assistantBufferRef.current);
          assistantBufferRef.current = "";
        }
        streamRef.current = null;
        dispatch(setStreaming(false));
      }
    );
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={90}
    >
      <ScrollView
        ref={scrollRef}
        style={styles.messageList}
        contentContainerStyle={styles.messageListContent}
        onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: true })}
      >
        {messages.map((m: any, i: number) => {
          const isUser = m.role === "user";
          const isLastAssistant = !isUser && i === messages.length - 1;
          const showDots = isLastAssistant && streaming && m.content === "";

          return (
            <View
              key={i}
              style={[styles.bubbleWrapper, isUser ? styles.bubbleWrapperRight : styles.bubbleWrapperLeft]}
            >
              <View style={[styles.bubble, isUser ? styles.bubbleUser : styles.bubbleAssistant]}>
                {showDots ? (
                  <TypingDots />
                ) : (
                  <Text style={[styles.bubbleText, isUser ? styles.bubbleTextUser : styles.bubbleTextAssistant]}>
                    {m.content}
                  </Text>
                )}
              </View>
            </View>
          );
        })}
      </ScrollView>

      {streaming && (
        <TouchableOpacity onPress={stopGenerating} style={styles.stopBtn} activeOpacity={0.7}>
          <Text style={styles.stopBtnText}>◼  Stop generating</Text>
        </TouchableOpacity>
      )}

      <View style={styles.inputRow}>
        <TextInput
          value={input}
          onChangeText={setInput}
          placeholder="Message..."
          placeholderTextColor="#999"
          multiline
          style={styles.input}
          onSubmitEditing={sendMessage}
          returnKeyType="send"
          blurOnSubmit={false}
        />
        <TouchableOpacity
          onPress={sendMessage}
          disabled={!input.trim() || streaming}
          style={[styles.sendBtn, (!input.trim() || streaming) && styles.sendBtnDisabled]}
          activeOpacity={0.7}
        >
          <Text style={styles.sendBtnText}>➤</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

// ── Styles ───────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F5F7FA",
  },
  messageList: {
    flex: 1,
  },
  messageListContent: {
    paddingHorizontal: 12,
    paddingTop: 16,
    paddingBottom: 8,
  },

  // Bubbles
  bubbleWrapper: {
    marginBottom: 10,
    flexDirection: "row",
  },
  bubbleWrapperRight: {
    justifyContent: "flex-end",
  },
  bubbleWrapperLeft: {
    justifyContent: "flex-start",
  },
  bubble: {
    maxWidth: "78%",
    borderRadius: 18,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  bubbleUser: {
    backgroundColor: "#0A84FF",
    borderBottomRightRadius: 4,
  },
  bubbleAssistant: {
    backgroundColor: "#FFFFFF",
    borderBottomLeftRadius: 4,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  bubbleText: {
    fontSize: 15,
    lineHeight: 21,
  },
  bubbleTextUser: {
    color: "#FFFFFF",
  },
  bubbleTextAssistant: {
    color: "#1C1C1E",
  },

  // Typing dots
  dotsRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 4,
    gap: 5,
  },
  dot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: "#8E8E93",
  },

  // Input bar
  inputRow: {
    flexDirection: "row",
    alignItems: "flex-end",
    paddingHorizontal: 12,
    paddingVertical: 10,
    backgroundColor: "#FFFFFF",
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: "#E0E0E0",
    gap: 8,
  },
  input: {
    flex: 1,
    minHeight: 40,
    maxHeight: 120,
    backgroundColor: "#F0F0F5",
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingTop: Platform.OS === "ios" ? 10 : 8,
    paddingBottom: Platform.OS === "ios" ? 10 : 8,
    fontSize: 15,
    color: "#1C1C1E",
  },
  sendBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#0A84FF",
    alignItems: "center",
    justifyContent: "center",
  },
  sendBtnDisabled: {
    backgroundColor: "#C7C7CC",
  },
  sendBtnText: {
    color: "#FFFFFF",
    fontSize: 16,
    marginLeft: 2,
  },
  stopBtn: {
    alignSelf: "center",
    marginBottom: 8,
    paddingHorizontal: 18,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1.5,
    borderColor: "#8E8E93",
    backgroundColor: "#FFFFFF",
  },
  stopBtnText: {
    color: "#3A3A3C",
    fontSize: 14,
    fontWeight: "500",
  },
});